self.__precacheManifest = [
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "//static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "39234bbd0d890c9d28bf",
    "url": "//static/js/runtime~main.39234bbd.js"
  },
  {
    "revision": "7bcb080a626fc188500d",
    "url": "//static/js/main.7bcb080a.chunk.js"
  },
  {
    "revision": "fa92c112869d3657d47b",
    "url": "//static/js/1.fa92c112.chunk.js"
  },
  {
    "revision": "7bcb080a626fc188500d",
    "url": "//static/css/main.3333f6bb.chunk.css"
  },
  {
    "revision": "92a47e7e56ac85f7227e6d5c1862952b",
    "url": "//index.html"
  }
];